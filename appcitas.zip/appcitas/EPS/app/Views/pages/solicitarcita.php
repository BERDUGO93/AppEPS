<body>
<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
<?php endif; ?>


  <div class="container">
    <h1 class="mt-4">Solicitud de Citas Médicas</h1>
    
    <form action="solicitar" method="POST">
    <?= csrf_field() ?>
      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre completo</label>
        <input type="text" class="form-control" id="nombre" name="nombre" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">Correo electrónico</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>

      <div class="mb-3">
        <label for="telefono" class="form-label">Teléfono</label>
        <input type="tel" class="form-control" id="telefono" name="telefono" required>
      </div>

      <div class="mb-3">
        <label for="especialidad" class="form-label">Especialidad Médica</label>
        <select class="form-select" id="especialidad" name="especialidad" required>
          <option value="">Seleccionar especialidad</option>
          <option value="cardiologia">Cardiología</option>
          <option value="odontologia">odontologia</option>
          <option value="neurologia">neurologia</option>
          <option value="dermatologia">Dermatología</option>
          <option value="gastroenterologia">Gastroenterología</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="fecha" class="form-label">Fecha de la cita</label>
        <input type="date" class="form-control" id="fecha" name="fecha" required>
      </div>
      
      <div class="mb-3">
        <label for="hora" class="form-label">Hora de la cita</label>
        <input type="time" class="form-control" id="hora" name="hora" required>
      </div>

      <div class="mb-3">
        <label for="mensaje" class="form-label">Mensaje adicional</label>
        <textarea class="form-control" id="mensaje" name="mensaje" rows="4"></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Solicitar Cita</button>
    </form>
  </div>
</body>
