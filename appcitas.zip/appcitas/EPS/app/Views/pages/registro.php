<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-header text-center">
                <img src="<?php echo base_url()?>/img/agregar-usuario.png" class="img-fluid" height="200" width="200"   alt="logo registro">
                    <h4> Formulario de  Registro</h4>
                </div>
                <div class="card-body">
                
                    
                    <form  id="form-registro" method="post" action="Registro">
                    <?= csrf_field() ?>
                  
                        <div class="mb-3">
                            <label for="documento" class="form-label">Documento</label>
                            <input type="text" name="documento" maxlength="10" class="form-control" id="documento" required >
                        </div>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" name="nombre" class="form-control" id="nombre"  required>
                        </div>
                        <div class="mb-3">
                            <label for="apellido" class="form-label">Apellido</label>
                            <input type="text" name="apellido" class="form-control" id="apellido" required>
                        </div>
                        <div class="mb-3">
                            <label for="telefono" class="form-label">Teléfono</label>
                            <input type="tel" name="telefono" class="form-control" id="telefono"  required>
                        </div>
                        <div class="mb-3">
                            <label for="correo" class="form-label">Correo electrónico</label>
                            <input type="email" name="correo" class="form-control" id="correo"  required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" name="password" minlength="10" maxlength="15" class="form-control" id="password"  required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Registrar</button>
                            <a href="<?php echo base_url()?>/login" >Inicia sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
