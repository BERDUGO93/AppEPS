<body>
<?php if (session()->getFlashdata('error')): ?>
  <div class="alert alert-danger">
    <?= session()->getFlashdata('error') ?>
  </div>
<?php endif; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mt-5">
                <div class="card-header text-center">
                <img src="<?php echo base_url()?>/img/iniciar-sesion.png" class="img-fluid" height="200" width="200"   alt="logo registro">
                    <h4>Iniciar sesión</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo base_url('validar'); ?>">
                    <?= csrf_field() ?>
                  
                        <div class="mb-3">
                            <label for="username" class="form-label">Usuario</label>
                            <input type="email" name="correo" class="form-control" id="correo" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" id="password" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Iniciar sesión</button>
                            <a href="<?php echo base_url()?>/registro" >Registrarse</button>
                        </div><br>
                        
                            
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
