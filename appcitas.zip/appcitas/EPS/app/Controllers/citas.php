<?php

namespace App\Controllers;

use App\Models\nuevaCita;

class citas extends BaseController
{
    public function solicitarCita()
    {
        // Obtener los datos del formulario
        $nombre = $this->request->getPost('nombre');
        $email = $this->request->getPost('email');
        $telefono = $this->request->getPost('telefono');
        $especialidad = $this->request->getPost('especialidad');
        $fecha = $this->request->getPost('fecha');
        $hora = $this->request->getPost('hora');
        $mensaje = $this->request->getPost('mensaje');

        // Crear una instancia del modelo de citas
        $citaModel = new nuevaCita();

        // Preparar los datos para insertar en la base de datos
        $data = [
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono,
            'especialidad' => $especialidad,
            'fecha' => $fecha,
            'hora' => $hora,
            'mensaje' => $mensaje
        ];


        $citaModel->solicitarCita($data);


        session()->setFlashdata('success', '¡Su cita ha sido agendada con éxito!');


        return redirect()->back();
    }
}
