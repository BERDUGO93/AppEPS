<?php

namespace App\Controllers;

use App\Models\nuevoUsuario;

class Login extends BaseController
{
    public function index()
    {
        return view('templates/header')
        . view('pages/login')
        . view('templates/footer');;
    }

    public function validar()
    {
        // Obtener los datos del formulario
        $correo = $this->request->getPost('correo');
        $password = $this->request->getPost('password');
  
        // Validar los datos de inicio de sesión
        $userModel = new nuevoUsuario();
        $user = $userModel->findByEmail($correo);
  
        if ($user && password_verify($password, $user['password'])) {
            // Las credenciales son válidas, realizar acciones adicionales o redireccionar
            // a la página de éxito
            return redirect()->to('okay');
        } else {
            // Las credenciales son inválidas, mostrar un mensaje de error o realizar acciones adicionales
            session()->setFlashdata('error', 'Usuario o contraseña incorrectos');
            return redirect()->back();
        }
    }

    public function okay()
    {
        return view('templates/header')
        . view('pages/solicitarcita')
        . view('templates/footer');;
        
    }

}
