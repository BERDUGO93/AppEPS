<?php


namespace App\Controllers;
use App\Models\nuevoUsuario;

class Registro extends BaseController
{

    public function __construct(){
        helper('url');
    }
    public function index()
    {
        return view('templates/header')
        . view('pages/registro')
        . view('templates/footer');;
    }

    public function registrar()
    {
        // Recibe los datos del formulario
        $documento = $this->request->getPost('documento');
        $nombre = $this->request->getPost('nombre');
        $apellido = $this->request->getPost('apellido');
        $telefono = $this->request->getPost('telefono');
        $correo = $this->request->getPost('correo');
        

        $password = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT);


        // Crea una instancia del modelo de usuarios
        $model = new nuevoUsuario();

        // Inserta los datos en la base de datos
        $data = [
            'documento' => $documento,
            'nombre' => $nombre,
            'apellido' => $apellido,
            'telefono' => $telefono,
            'correo' => $correo,
            'password' => $password,
        ];
        $model->insert($data);

        // Redirige a la página de éxito o muestra un mensaje
        return redirect()->to('exito');
    }

    public function exito()
    {
        return view('templates/header')
        . view('pages/login')
        . view('templates/footer');;
    }
}

