<?php

namespace App\Models;

use CodeIgniter\Model;

class nuevoUsuario extends Model
{
    protected $table = 'usuarios';
    protected $primaryKey = 'id';
    protected $allowedFields = ['documento', 'nombre', 'apellido', 'telefono', 'correo', 'password'];


    // Otras propiedades y configuraciones del modelo...

    // Ejemplo de método para buscar un usuario por correo electrónico
    public function findByEmail($email)
    {
        return $this->where('correo', $email)->first();
    }

    // Ejemplo de método para verificar la contraseña de un usuario
    public function verifyPassword($email, $password)
    {
        return password_verify($password, $email->password);
    }

    
}