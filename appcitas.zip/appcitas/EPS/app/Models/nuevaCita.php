<?php

namespace App\Models;

use CodeIgniter\Model;

class nuevaCita extends Model
{
    protected $table = 'citas';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'email', 'telefono', 'especialidad', 'fecha', 'hora', 'mensaje'];

    public function solicitarCita($data)
    {
        return $this->insert($data);
    }
}