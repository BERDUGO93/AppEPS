-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2023 a las 05:53:31
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `epsdb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `especialidad` varchar(30) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `mensaje` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`id`, `nombre`, `email`, `telefono`, `especialidad`, `fecha`, `hora`, `mensaje`, `created_at`, `updated_at`) VALUES
(1, 'Diego Alberto Berdugo Lopez', 'diegoberdugo.dbl@gmail.com', '3143808397', 'dermatologia', '2023-05-30', '13:50:00', 'cita valoracion', '2023-05-26 03:47:43', '2023-05-26 03:47:43');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `documento` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `documento`, `nombre`, `apellido`, `telefono`, `correo`, `password`) VALUES
(1, '1019081667', 'sd', 'berdugo', '3143808397', 'diegoberdugo.dbl@gmail.com', 'diego1993@'),
(2, '4272082', 'carlos', 'berdugo', '314380774334', 'carlosberdugo.l@gmail.com', '$2y$10$BLo6L87JbZRnM0fMY5Dwmu305eY85vYYiBcrBETyOHmfMp8qvbemq'),
(3, '51615912', 'ana', 'lopez', '3126578523', 'analopez@gmail.com', '$2y$10$JSvyKtC6A/nmxNlNQFytVeYLYG7/0/9NpmqCo21qeqLF53pos2/Re'),
(4, '51615923', 'jose', 'lopez', '3126578445', 'joselopez@gmail.com', '$2y$10$1Zdjd83Xq5IDda0GS27LBOMQmnvKtotqP6ADDBv2IUVvyI/dHQO1i'),
(5, '12345678', 'diego', 'lopez', '3179079642', 'diego_-15@hotmail.com', '$2y$10$SLE51M17mWk2eIGg8eOEge0zzCPUD77p9qcC8eHCpxQpel2f2AXha');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `citas`
--
ALTER TABLE `citas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
